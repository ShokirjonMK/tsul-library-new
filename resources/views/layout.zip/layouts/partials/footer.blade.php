
<footer class="footer mt-auto">
	<div class="copyright bg-white">
		<p>
			Copyright &copy; <span id="ec-year"></span> All Rights Reserved.
			</p>
	</div>
</footer>
